// Agregar validaciones o comportamiento personalizado si es necesario

document.getElementById('cotizacionForm').addEventListener('submit', function(event) {
    // Validación extra o acciones antes de enviar el formulario
    alert('Formulario enviado exitosamente.');
});
